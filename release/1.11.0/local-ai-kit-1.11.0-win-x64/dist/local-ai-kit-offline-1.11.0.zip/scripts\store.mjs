/**
 * 本地持久化存储。
 *
 * 控制台需要存一些「跨进程、跨重启」的数据：
 *   - 体检 / 测速的历史（用来画趋势）
 *   - 试用页的对话（关了浏览器还想接着聊）
 *   - 自己攒的提示词模板
 *
 * 全部放在用户数据目录下的一个 JSON 文件里，原子写入，条数有上限。
 * 不进安装目录 —— 卸载时不用清理，也避免用户误删安装目录导致数据丢失。
 */

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

/**
 * 存储文件的位置。
 *
 * 延迟计算（而不是 import 时就定死），这样测试可以临时改
 * LOCAL_AI_DATA_DIR 指向临时目录，不污染真实数据。
 */
export function storeDir() {
  return process.env.LOCAL_AI_DATA_DIR
    || path.join(process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'LocalAI');
}

export function storeFile() {
  return path.join(storeDir(), 'store.json');
}

/** 各类型最多留多少条（多了文件会变得很臃肿） */
const LIMITS = {
  health: 60,
  bench: 60,
  chat: 20,
  templates: 50,
  notes: 100,
  usage: 120,
};

function ensureDir() {
  try { fs.mkdirSync(storeDir(), { recursive: true }); } catch { /* ignore */ }
}

/**
 * 读整个存储。文件不存在或坏了都返回空骨架，不抛异常 ——
 * 「历史丢了」不该让控制台起不来。
 */
export function readStore() {
  try {
    const raw = fs.readFileSync(storeFile(), 'utf8').replace(/^\uFEFF/, '');
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
    return parsed;
  } catch { return {}; }
}

/** 写整个存储：先写临时文件再改名，避免中途断电留半个文件 */
export function writeStore(store) {
  ensureDir();
  const file = storeFile();
  const temp = `${file}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(temp, JSON.stringify(store, null, 2), 'utf8');
    fs.renameSync(temp, file);
  } finally { try { fs.rmSync(temp, { force: true }); } catch { /* ignore */ } }
  return store;
}

/** 读某一类数据 */
export function readList(kind) {
  const store = readStore();
  const list = store[kind];
  return Array.isArray(list) ? list : [];
}

/**
 * 往某一类里追加一条，超过上限就丢最旧的。
 * @param {string} kind
 * @param {object} item
 */
export function appendItem(kind, item) {
  const store = readStore();
  const list = Array.isArray(store[kind]) ? store[kind] : [];
  list.push(item);
  const limit = LIMITS[kind] || 50;
  while (list.length > limit) list.shift();
  store[kind] = list;
  writeStore(store);
  return item;
}

/** 覆盖某一类的全部内容 */
export function writeList(kind, list) {
  const store = readStore();
  const limit = LIMITS[kind] || 50;
  store[kind] = Array.isArray(list) ? list.slice(-limit) : [];
  writeStore(store);
  return store[kind];
}

/** 清空某一类 */
export function clearList(kind) {
  const store = readStore();
  store[kind] = [];
  writeStore(store);
  return [];
}

/** 存储文件在哪（界面上要告诉用户） */
export function storePath() {
  return storeFile();
}

/* ------------------------------------------------------------ 文件小工具 */

/**
 * 原子写一个文本文件：先写 `.tmp` 再改名。
 *
 * 直接 `writeFileSync` 覆盖的话，写到一半断电 / 被杀就是半截文件，
 * 而读的一方（比如出字快测的记录）多半会静默当成「没有数据」，历史全丢。
 */
export function writeFileAtomic(file, text) {
  const temp = `${file}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(temp, text, 'utf8');
    fs.renameSync(temp, file);
  } finally { try { fs.rmSync(temp, { force: true }); } catch { /* ignore */ } }
}

/**
 * 读文件末尾的若干字节（不整份读进内存）。
 *
 * 日志是追加写的，跑几天就是几百 MB；而「看最后 200 行」这种需求
 * 每隔几秒就来一次。`readFileSync` 整份读再 slice 会把事件循环卡住。
 *
 * @param {string} file
 * @param {number} maxBytes 最多读多少字节（从文件末尾算）
 * @returns {string} 读不到时返回空串
 */
export function tailBytes(file, maxBytes = 8192) {
  try {
    const size = fs.statSync(file).size;
    const want = Math.min(size, Math.max(1, maxBytes));
    const buf = Buffer.alloc(want);
    const fd = fs.openSync(file, 'r');
    try { fs.readSync(fd, buf, 0, want, size - want); } finally { fs.closeSync(fd); }
    let text = buf.toString('utf8');
    // 从中间切开时第一行可能是半行（甚至是半个多字节字符），丢掉
    if (want < size) {
      const nl = text.indexOf('\n');
      text = nl >= 0 ? text.slice(nl + 1) : text;
    }
    return text;
  } catch { return ''; }
}
